﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _097LJServicios
{
    public class _097LJUsuario: _097LJEntity
    {
        public string _097LJEmail { get; set; }
        public string _097LJPassword { get; set; }
        public override string ToString()
        {
            return _097LJEmail;
        }
    }
}
