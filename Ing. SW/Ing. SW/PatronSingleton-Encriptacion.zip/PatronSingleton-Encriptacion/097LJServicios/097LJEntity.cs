﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _097LJServicios
{
    public abstract class _097LJEntity
    {
        public _097LJEntity()
        {
            Id = Guid.NewGuid();
        }
        public Guid Id { get; }
    }
}
