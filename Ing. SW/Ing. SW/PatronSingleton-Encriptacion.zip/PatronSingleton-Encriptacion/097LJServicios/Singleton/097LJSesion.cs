﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _097LJServicios.Singleton
{
    public class _097LJSesion
    {
        private _097LJUsuario _user { get; set; }

        public _097LJUsuario Usuario
        {
            get
            {
                return _user;
            }
        }
        public void _097LJLogin(_097LJUsuario usuario)
        {
            _user = usuario;
        }

        public void _097LJLogout()
        {
            _user = null;
        }
        public bool _097LJIsLogged()
        {
            return _user != null;
        }
    }
}
