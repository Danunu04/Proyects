﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _097LJServicios.Singleton
{
    public enum _097LJLoginResult
    {
        InvalidUsername,
        InvalidPassword,
        ValidUser
    }
}
