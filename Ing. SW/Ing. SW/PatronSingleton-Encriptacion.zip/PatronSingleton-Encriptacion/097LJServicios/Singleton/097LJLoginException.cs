﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _097LJServicios.Singleton
{
    public class _097LJLoginException : Exception
    {
        public _097LJLoginResult Result;

        public _097LJLoginException(_097LJLoginResult result)
        {
            Result = result;
        }
    }
}
