﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _097LJServicios.Singleton
{
    public class _097LJSingletonSession
    {
        private static _097LJSesion _instancia;
        private static Object _lock = new object();

        public static _097LJSesion Instancia
        {
            get
            {
                lock (_lock)
                {
                    if (_instancia == null)
                        _instancia = new _097LJSesion();
                }

                return _instancia;
            }
        }
    }
}
