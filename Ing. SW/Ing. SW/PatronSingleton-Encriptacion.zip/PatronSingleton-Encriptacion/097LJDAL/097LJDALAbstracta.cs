﻿using _097LJServicios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _097LJDAL
{
    public abstract class _097LJDALAbstracta<T> : _097LJICrud <T> where T : _097LJEntity
    {
        protected IList<T> dataContext;
        public _097LJDALAbstracta()
        {
            dataContext = new List<T>();
        }

        public void Delete(T entity)
        {
            this.dataContext.Remove(entity);
        }

        public IList<T> GetAll()
        {
            return dataContext;
        }

        public T GetById(Guid id)
        {
            return dataContext.Where(i => i.Id.Equals(id)).FirstOrDefault();
        }

        public void Save(T entity)
        {
            if (dataContext.Contains(entity))
            {
               
            }
            else
            {
                dataContext.Add(entity);
            }

        }
    }
}
