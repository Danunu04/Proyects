﻿using _097LJServicios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _097LJDAL
{
    public interface _097LJICrud<T> where T : _097LJEntity
    {
        T GetById(Guid id);
        IList<T> GetAll();
        void Save(T entity);
        void Delete(T entity);
    }
}
