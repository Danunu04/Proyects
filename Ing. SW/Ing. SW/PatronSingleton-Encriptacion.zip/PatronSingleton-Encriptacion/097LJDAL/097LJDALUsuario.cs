﻿using _097LJServicios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _097LJDAL
{
    public class _097LJDALUsuario :_097LJDALAbstracta<_097LJUsuario>
    {
    }
}
