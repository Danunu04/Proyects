﻿using _097LJDAL;
using _097LJServicios;
using _097LJServicios.Singleton;
using ServiceStack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _097LJBLL
{
    public class _097LJBLLUsuario : _097LJBLLAbstracta<_097LJUsuario>
    {
        public _097LJBLLUsuario()
        {
            _crud = new _097LJDALUsuario();
            _097LJSimularDatos();
        }
        private void _097LJSimularDatos()
        {
            var u = new _097LJUsuario();
            u._097LJEmail = "u1@mail.com";
            u._097LJPassword = _097LJEncriptador._097LJEncriptar("123");
            _crud.Save(u);

            u = new _097LJUsuario();
            u._097LJEmail = "u2@mail.com";
            u._097LJPassword = _097LJEncriptador._097LJEncriptar("123");
            _crud.Save(u);

            u = new _097LJUsuario();
            u._097LJEmail = "admin@mail.com";
            u._097LJPassword = _097LJEncriptador._097LJEncriptar("123");
            _crud.Save(u);
        }
        public _097LJLoginResult _097LJLogin(string email, string password)
        {

            if (_097LJSingletonSession.Instancia._097LJIsLogged())
                throw new Exception("Ya hay una sesión iniciada"); 
            var user = _crud.GetAll().Where(u => u._097LJEmail.Equals(email)).FirstOrDefault();
            if (user == null) throw new _097LJLoginException(_097LJLoginResult.InvalidUsername);

            if (!_097LJEncriptador._097LJEncriptar(password).Equals(user._097LJPassword))
                throw new _097LJLoginException(_097LJLoginResult.InvalidPassword);
            else
            {
                _097LJSingletonSession.Instancia._097LJLogin(user);
                return _097LJLoginResult.ValidUser;
            }
        }

        public void _097LJLogout()
        {
            if (!_097LJSingletonSession.Instancia._097LJIsLogged())
                throw new Exception("No hay sesión iniciada");

            _097LJSingletonSession.Instancia._097LJLogout();
        }
    }
}
