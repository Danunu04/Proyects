﻿using _097LJDAL;
using _097LJServicios;
using ServiceStack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _097LJBLL
{
    public abstract class _097LJBLLAbstracta<T> : _097LJICrud<T> where T : _097LJEntity
    {
        protected _097LJICrud<T> _crud;
        public void Delete(T entity)
        {
            _crud.Delete(entity);
        }

        public IList<T> GetAll()
        {
            return _crud.GetAll();
        }

        public T GetById(Guid id)
        {
            return _crud.GetById(id);
        }

        public void Save(T entity)
        {
            _crud.Save(entity);

        }
    }
}
