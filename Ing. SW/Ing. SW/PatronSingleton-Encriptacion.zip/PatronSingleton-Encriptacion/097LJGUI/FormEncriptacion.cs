﻿using _097LJServicios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _097LJGUI
{
    public partial class FormEncriptacion : Form
    {
        public FormEncriptacion()
        {
            InitializeComponent();
        }

        private void chkVerContraseña_CheckedChanged(object sender, EventArgs e)
        {
            txtContraseña.UseSystemPasswordChar = !chkVerContraseña.Checked;
        }

        private void btnIngresarSistema_Click(object sender, EventArgs e)
        {
            string contraseña = txtContraseña.Text;
            string resultadomd5 = _097LJEncriptador._097LJEncriptar(contraseña);
            string resultadosha256 = _097LJEncriptador.EncriptarSHA256(contraseña);
            txtContraseñaEncriptada.Text = resultadomd5;
            txtContraseñasha256.Text = resultadosha256;
        }

        private void txtLimpiar_Click(object sender, EventArgs e)
        {
            txtContraseña.Text = "";
            txtContraseñaEncriptada.Text = "";
            txtContraseñasha256.Text = "";
        }
    }
}
