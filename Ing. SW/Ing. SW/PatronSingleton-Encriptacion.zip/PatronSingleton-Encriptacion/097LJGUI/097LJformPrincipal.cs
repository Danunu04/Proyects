﻿using _097LJBLL;
using _097LJServicios.Singleton;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _097LJGUI
{
    public partial class _097LJformPrincipal : Form
    {
        _097LJBLLUsuario _097LJusuariobll;
        public _097LJformPrincipal()
        {
            InitializeComponent();
            _097LJValidarForm();
            _097LJusuariobll = new _097LJBLLUsuario();
        }
        public void _097LJValidarForm()
        {

            this.itemLogin.Enabled = !_097LJSingletonSession.Instancia._097LJIsLogged();
            this.itemLogout.Enabled = _097LJSingletonSession.Instancia._097LJIsLogged();
            this.itemEncriptacionIrreversible.Enabled = _097LJSingletonSession.Instancia._097LJIsLogged();

            if (_097LJSingletonSession.Instancia._097LJIsLogged())
                this.toolStripSesion.Text = _097LJSingletonSession.Instancia.Usuario._097LJEmail;
            else
                this.toolStripSesion.Text = "[Sesión no iniciada]";
        }
        private void itemLogin_Click(object sender, EventArgs e)
        {

            _097LJFrmLogin frm = new _097LJFrmLogin();
            frm.MdiParent = this;
            frm.Show();
        }

        private void itemLogout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Está seguro que desea Cerrar Sesion?", "Atencion", MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
            {
                _097LJusuariobll._097LJLogout();
                _097LJValidarForm();
            }
        }

        private void _097LJformPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void itemEncriptacionIrreversible_Click(object sender, EventArgs e)
        {
            FormEncriptacion frmencriptacion= new FormEncriptacion();
            frmencriptacion.MdiParent = this;
            frmencriptacion.Show();
        }
    }
}
