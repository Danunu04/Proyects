﻿using _097LJBLL;
using _097LJServicios.Singleton;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _097LJGUI
{
    public partial class _097LJFrmLogin : Form
    {
        _097LJBLLUsuario _097LJusuariobll;
        public _097LJFrmLogin()
        {
            InitializeComponent();
            _097LJusuariobll=new _097LJBLLUsuario();
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            try
            {
                var res = _097LJusuariobll._097LJLogin(this.txtEmail.Text, this.txtPassword.Text);
                _097LJformPrincipal frm = (_097LJformPrincipal)this.MdiParent;
                frm._097LJValidarForm();

                this.Close();
            }
            catch (_097LJLoginException error)
            {
                switch (error.Result)
                {
                    case _097LJLoginResult.InvalidUsername:
                        MessageBox.Show("Usuario incorrecto");
                        break;
                    case _097LJLoginResult.InvalidPassword:
                        MessageBox.Show(" Contraseña Incorrecto");
                        break;

                    default:
                        break;
                }

            }
        }
        private void btnsalir_Click(object sender, EventArgs e)
        {
            this.Close();   
        }
    }
}
