﻿namespace _097LJGUI
{
    partial class FormEncriptacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtContraseña = new System.Windows.Forms.TextBox();
            this.txtContraseñaEncriptada = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.chkVerContraseña = new System.Windows.Forms.CheckBox();
            this.btnIngresarSistema = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtContraseñasha256 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtContraseña
            // 
            this.txtContraseña.Location = new System.Drawing.Point(126, 37);
            this.txtContraseña.Name = "txtContraseña";
            this.txtContraseña.Size = new System.Drawing.Size(178, 20);
            this.txtContraseña.TabIndex = 0;
            this.txtContraseña.UseSystemPasswordChar = true;
            // 
            // txtContraseñaEncriptada
            // 
            this.txtContraseñaEncriptada.Location = new System.Drawing.Point(126, 74);
            this.txtContraseñaEncriptada.Name = "txtContraseñaEncriptada";
            this.txtContraseñaEncriptada.Size = new System.Drawing.Size(178, 20);
            this.txtContraseñaEncriptada.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Contraseña:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Contraseña Encriptada:";
            // 
            // chkVerContraseña
            // 
            this.chkVerContraseña.AutoSize = true;
            this.chkVerContraseña.Location = new System.Drawing.Point(311, 39);
            this.chkVerContraseña.Name = "chkVerContraseña";
            this.chkVerContraseña.Size = new System.Drawing.Size(42, 17);
            this.chkVerContraseña.TabIndex = 4;
            this.chkVerContraseña.Text = "Ver";
            this.chkVerContraseña.UseVisualStyleBackColor = true;
            this.chkVerContraseña.CheckedChanged += new System.EventHandler(this.chkVerContraseña_CheckedChanged);
            // 
            // btnIngresarSistema
            // 
            this.btnIngresarSistema.Location = new System.Drawing.Point(83, 155);
            this.btnIngresarSistema.Name = "btnIngresarSistema";
            this.btnIngresarSistema.Size = new System.Drawing.Size(178, 23);
            this.btnIngresarSistema.TabIndex = 5;
            this.btnIngresarSistema.Text = "Encriptar";
            this.btnIngresarSistema.UseVisualStyleBackColor = true;
            this.btnIngresarSistema.Click += new System.EventHandler(this.btnIngresarSistema_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(342, 1);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(27, 23);
            this.btnLimpiar.TabIndex = 6;
            this.btnLimpiar.Text = "X";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.txtLimpiar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Contraseña Encriptada:";
            // 
            // txtContraseñasha256
            // 
            this.txtContraseñasha256.Location = new System.Drawing.Point(126, 113);
            this.txtContraseñasha256.Name = "txtContraseñasha256";
            this.txtContraseñasha256.Size = new System.Drawing.Size(178, 20);
            this.txtContraseñasha256.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(322, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "MD5";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(322, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "SHA256";
            // 
            // FormEncriptacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(372, 190);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtContraseñasha256);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnIngresarSistema);
            this.Controls.Add(this.chkVerContraseña);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtContraseñaEncriptada);
            this.Controls.Add(this.txtContraseña);
            this.Name = "FormEncriptacion";
            this.Text = "FormEncriptacion";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtContraseña;
        private System.Windows.Forms.TextBox txtContraseñaEncriptada;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chkVerContraseña;
        private System.Windows.Forms.Button btnIngresarSistema;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtContraseñasha256;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}